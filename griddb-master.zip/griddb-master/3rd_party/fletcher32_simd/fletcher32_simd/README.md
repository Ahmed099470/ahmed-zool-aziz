# fletcher32-simd
SIMD accelerated Fletcher32 algorithm implementations
