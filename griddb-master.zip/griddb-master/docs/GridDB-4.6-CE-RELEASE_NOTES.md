# GridDB CE 4.6

## Changelog

Main changes in GridDB CE v4.6 are as follows:

1. Enhanced Functionality and Performance Improvement for SQL
    - Aggregate functions with DISTINCT and WINDOW function are added.
    - SQL processing for various data types has been improved.
2. CLI(Command Line Interface)
    - The GridDB CLI provides command line interface tool to manage GridDB cluster operations and data operations.

